const canvas = document.querySelector("#canvas");
const ctx = canvas.getContext("2d");
const game1 = document.querySelector(".game2048");
const main = document.querySelector(".main");

let player = { "x": 200, "y": canvas.height, "size": 50, "speed": 3 };
let strArr = ['-2048-','미정','미정','미정'];
let keyDown = {};
let gameArr = {};
let mList = [];
let time = window.setInterval(draw, 10);
let runningGame = false;

let machineImg = new Image();
machineImg.src = "./gamemachine.png";

window.addEventListener("keydown", (e) => {
    keyDown[e.key] = true;
})
window.addEventListener("keyup", (e) => {
    keyDown[e.key] = false;
})

window.onload = function () {
    let index  = 50; 
    let cnt = 0;
    for (let i = 0; i < 4; i++) {
        let m = new game();
        mList.push(m);
    }

    mList.forEach((e) => {e.init(index+=120 ,90,50,strArr[cnt++])})
    mList.forEach((e) => {console.log(e);})
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    movePlayer();
    mList.forEach((m)=>{
        m.render(ctx);
    })
    drawPlayer();
    crash();

}

function crash() {
    if(player.y <= 145 && (player.x >= 150 && player.x <=220)){
        player.y += 50;
        game1.style = 'z-index :1';
        main.style = 'z-index :0';
    }else if(player.y <= 145 && (player.x >= 270 && player.x <=340)){
        player.y += 50;
    }
}


function drawMachine(x,y) {
    ctx.beginPath();
    ctx.drawImage(machineImg,x,y,70,70);
    ctx.closePath();
}

function drawPlayer() {
    ctx.beginPath();
    ctx.fillStyle = 'green';
    ctx.fillRect(player.x,player.y,player.size,player.size);
    ctx.closePath();
}

function movePlayer() {
    if (keyDown["ArrowUp"]) {
        player.y -= player.speed;
    } else if (keyDown["ArrowRight"]) {
        player.x += player.speed;

    } else if (keyDown["ArrowDown"]) {
        player.y += player.speed;
    } else if (keyDown["ArrowLeft"]) {
        player.x -= player.speed;
    }

    if (player.x <= 0) player.x = 0;
    if (player.y <= 0) player.y = 0;
    if (player.x >= canvas.width - player.size) player.x = canvas.width - player.size;
    if (player.y >= canvas.height - player.size) player.y = canvas.height - player.size;

}


